from __future__ import annotations

import json
import re
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import func, case
from sqlalchemy.orm import Session

from ...config import RUNS_DIR, WORKFLOWS_DIR
from ...db import Finding, Run, RunLog, get_db_dep, run_to_dict, db_get
from ...tasks import execute_run

router = APIRouter(tags=["runs"])


class RunCreate(BaseModel):
    workflow: str
    target: str
    out: str | None = None
    vars: list[str] = []
    resume: bool = False
    continue_on_error: bool = False


def launch_run(
    db,
    workflow: str,
    target: str,
    vars_dict: dict[str, str] | None = None,
    out: str | None = None,
    resume: bool = False,
    continue_on_error: bool = False,
    origin: str | None = None,
) -> Run:
    """Shared run-creation path (UI, schedules, resume). Returns the queued Run."""
    wf_path = (WORKFLOWS_DIR / workflow).resolve()
    if not wf_path.is_relative_to(WORKFLOWS_DIR.resolve()):
        raise HTTPException(400, "Invalid workflow path")
    if not wf_path.exists():
        raise HTTPException(404, f"Workflow not found: {workflow}")

    if out:
        workspace = str((RUNS_DIR / out).resolve())
        if not (RUNS_DIR / out).resolve().is_relative_to(RUNS_DIR.resolve()):
            raise HTTPException(400, "Invalid output path")
    else:
        safe_target = re.sub(r"[^A-Za-z0-9._-]+", "_", target)
        ts = time.strftime("%Y%m%d-%H%M%S")
        workspace = str(RUNS_DIR / safe_target / ts)

    try:
        wf_data = yaml.safe_load(wf_path.read_text(encoding="utf-8"))
        from ...workflow import render_template
        # Pre-render each step's command (target/workspace/vars are known at
        # creation time) so the UI can show WHAT is running per step.
        # Unknown placeholders ({steps.X.file}) stay literal via allow_missing.
        merged_vars = dict(wf_data.get("vars") or {})
        merged_vars.update(vars_dict or {})
        ctx = {
            **merged_vars, "vars": merged_vars,
            "target": target, "workspace": workspace,
            "timestamp": time.strftime("%Y%m%d-%H%M%S"), "steps": {},
        }
        steps_meta = []
        for s in wf_data.get("steps", []):
            if not isinstance(s, dict) or "id" not in s:
                continue
            meta = {"id": s["id"], "status": "pending", "name": s.get("name") or ""}
            try:
                if isinstance(s.get("fanout"), list):
                    meta["fanout"] = [
                        {"id": c.get("id", "?"),
                         "cmd": render_template(str(c.get("run", "")), ctx, allow_missing=True)}
                        for c in s["fanout"] if isinstance(c, dict)
                    ]
                elif s.get("run"):
                    meta["cmd"] = render_template(str(s["run"]), ctx, allow_missing=True)
            except Exception:
                pass
            steps_meta.append(meta)
        steps_json = json.dumps(steps_meta)
    except Exception:
        steps_json = json.dumps([])

    run_id = uuid.uuid4().hex[:12]
    run = Run(
        id=run_id,
        workflow=workflow,
        target=target,
        workspace=workspace,
        steps_json=steps_json,
        vars_json=json.dumps(vars_dict or {}),
        out_dir=out,
        continue_on_error=continue_on_error,
        resume=resume,
        status="queued",
    )
    db.add(run)
    db.commit()

    cmd = [sys.executable, "-m", "k1nzr3c0n", "run", "-w", str(wf_path), "-t", target, "-o", workspace]
    if resume:
        cmd.append("--resume")
    if continue_on_error:
        cmd.append("--continue-on-error")
    if vars_dict:
        cmd += ["--vars"] + [f"{k}={v}" for k, v in vars_dict.items()]

    task = execute_run.delay(run_id, cmd)
    run.celery_task_id = task.id
    db.commit()
    return run


@router.post("/runs", status_code=201)
def create_run(body: RunCreate, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    # Deny-wins scope gate: registered targets marked oos block run creation
    # (unregistered targets pass through but land in the scope audit log).
    from ...scope import check_target_scope
    allowed, reason = check_target_scope(db, body.target)
    if not allowed:
        raise HTTPException(403, f"Out of scope: {reason}")

    vars_dict = {k: v for item in (body.vars or []) for k, v in [item.split("=", 1)]}
    run = launch_run(
        db,
        workflow=body.workflow,
        target=body.target,
        vars_dict=vars_dict,
        out=body.out,
        resume=body.resume,
        continue_on_error=body.continue_on_error,
        origin="ui",
    )
    return run_to_dict(run)


@router.get("/runs/{run_id}/new-assets")
def run_new_assets(run_id: str, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    """Assets discovered for the first time in this run (vs earlier runs)."""
    from ...db import NewAsset, new_asset_to_dict
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    rows = db.query(NewAsset).filter(NewAsset.run_id == run_id).order_by(NewAsset.host).all()
    return {"total": len(rows), "items": [new_asset_to_dict(a) for a in rows]}


@router.get("/runs")
def list_runs(
    status: str | None = Query(None),
    workflow: str | None = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    db: Session = Depends(get_db_dep),
) -> dict[str, Any]:
    q = db.query(Run).order_by(Run.created_at.desc())
    if status:
        q = q.filter(Run.status == status)
    if workflow:
        q = q.filter(Run.workflow == workflow)
    total = q.count()
    runs = q.offset(offset).limit(limit).all()
    return {"total": total, "items": [run_to_dict(r) for r in runs]}


@router.get("/runs/stats")
def run_stats(db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    # SQLAlchemy 1.x compat: case([(condition, value)], else_=...)
    # SQLAlchemy 2.x also accepts this form (it's just deprecated, not removed)
    row = db.query(
        func.count(Run.id).label("total"),
        func.sum(case([(Run.status == "queued",    1)], else_=0)).label("queued"),
        func.sum(case([(Run.status == "running",   1)], else_=0)).label("running"),
        func.sum(case([(Run.status == "completed", 1)], else_=0)).label("completed"),
        func.sum(case([(Run.status == "failed",    1)], else_=0)).label("failed"),
    ).one()

    total_findings = db.query(func.count(Finding.id)).scalar() or 0
    open_vulns = db.query(func.count(Finding.id)).filter(
        Finding.kind == "vuln", Finding.status == "open"
    ).scalar() or 0

    sev_rows = (
        db.query(Finding.severity, func.count(Finding.id))
        .filter(Finding.kind == "vuln")
        .group_by(Finding.severity)
        .all()
    )
    by_severity = {(sev or "info"): cnt for sev, cnt in sev_rows}

    recent = db.query(Run).order_by(Run.created_at.desc()).limit(8).all()
    return {
        "total": row.total or 0,
        "by_status": {
            "queued":    row.queued    or 0,
            "running":   row.running   or 0,
            "completed": row.completed or 0,
            "failed":    row.failed    or 0,
        },
        "findings": {
            "total":       total_findings,
            "open_vulns":  open_vulns,
            "by_severity": by_severity,
        },
        "recent": [run_to_dict(r) for r in recent],
    }


@router.get("/runs/{run_id}")
def get_run(run_id: str, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    result = run_to_dict(run)
    total_logs = db.query(func.count(RunLog.id)).filter(RunLog.run_id == run_id).scalar() or 0
    result["total_logs"] = total_logs

    findings_count = db.query(func.count(Finding.id)).filter(Finding.run_id == run_id).scalar() or 0
    result["findings_count"] = findings_count
    return result


@router.get("/runs/{run_id}/logs")
def get_run_logs(
    run_id: str,
    offset: int = Query(0, ge=0),
    limit: int = Query(500, le=2000),
    db: Session = Depends(get_db_dep),
) -> dict[str, Any]:
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    total = db.query(func.count(RunLog.id)).filter(RunLog.run_id == run_id).scalar() or 0
    logs = (
        db.query(RunLog)
        .filter(RunLog.run_id == run_id)
        .order_by(RunLog.id)
        .offset(offset)
        .limit(limit)
        .all()
    )
    return {"total": total, "offset": offset, "limit": limit, "items": [l.message for l in logs]}


@router.post("/runs/{run_id}/cancel")
def cancel_run(run_id: str, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status not in ("queued", "running"):
        raise HTTPException(400, f"Cannot cancel run with status: {run.status}")

    # Write cancel flag so execute_run detects it and kills the subprocess cleanly
    if run.workspace:
        flag = Path(run.workspace) / "cancel.flag"
        flag.parent.mkdir(parents=True, exist_ok=True)
        flag.touch()

    # Revoke the Celery task (handles queued tasks that haven't started yet)
    if run.celery_task_id:
        from ...tasks import celery_app
        celery_app.control.revoke(run.celery_task_id, terminate=False)

    run.status = "cancelled"
    run.finished_at = datetime.utcnow()
    db.commit()
    return run_to_dict(run)


@router.post("/runs/{run_id}/pause")
def pause_run(run_id: str, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status != "running":
        raise HTTPException(400, f"Cannot pause run with status: {run.status}")
    if not run.workspace:
        raise HTTPException(400, "Run has no workspace")

    flag = Path(run.workspace) / "pause.flag"
    flag.parent.mkdir(parents=True, exist_ok=True)
    flag.touch()

    return {"ok": True, "message": "Pause requested — run will stop after the current step completes."}


@router.delete("/runs/{run_id}/pause")
def cancel_pause(run_id: str, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    """Remove the pause flag while a run is still running (cancel a pending pause)."""
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status != "running":
        raise HTTPException(400, f"Run is not running (status: {run.status})")
    if not run.workspace:
        raise HTTPException(400, "Run has no workspace")

    flag = Path(run.workspace) / "pause.flag"
    flag.unlink(missing_ok=True)

    return {"ok": True}


@router.post("/runs/{run_id}/resume")
def resume_run(run_id: str, db: Session = Depends(get_db_dep)) -> dict[str, Any]:
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    if run.status not in ("paused", "failed"):
        raise HTTPException(400, f"Cannot resume run with status: {run.status}")
    if not run.workspace:
        raise HTTPException(400, "Run has no workspace")

    # Clear pause flag so the next execution doesn't immediately pause again
    flag = Path(run.workspace) / "pause.flag"
    flag.unlink(missing_ok=True)

    # Reset any step that is paused/failed/running back to pending for the UI
    steps = json.loads(run.steps_json or "[]")
    for s in steps:
        if s.get("status") in ("paused", "failed", "running"):
            s["status"] = "pending"

    run.status = "running"
    run.finished_at = None
    run.paused_at = None
    run.steps_json = json.dumps(steps)
    db.commit()

    wf_path = (WORKFLOWS_DIR / run.workflow).resolve()
    vars_dict = json.loads(run.vars_json or "{}")
    cmd = [
        sys.executable, "-m", "k1nzr3c0n", "run",
        "-w", str(wf_path),
        "-t", run.target,
        "-o", run.workspace,
        "--resume",
    ]
    if run.continue_on_error:
        cmd.append("--continue-on-error")
    if vars_dict:
        cmd += ["--vars"] + [f"{k}={v}" for k, v in vars_dict.items()]

    from ...tasks import execute_run
    task = execute_run.delay(run_id, cmd)
    run.celery_task_id = task.id
    db.commit()

    return run_to_dict(run)


@router.delete("/runs/{run_id}", status_code=204)
def delete_run(run_id: str, db: Session = Depends(get_db_dep)) -> None:
    run = db_get(db, Run, run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    db.query(RunLog).filter(RunLog.run_id == run_id).delete()
    db.query(Finding).filter(Finding.run_id == run_id).delete()
    db.delete(run)
    db.commit()
