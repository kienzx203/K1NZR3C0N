"""Parse tool output files from a run workspace into structured Finding rows."""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path
from urllib.parse import urlsplit

from ..db import Finding


def _netloc_key(url: str) -> str | None:
    """Normalise a URL → "host" or "host:port" key for screenshot matching.

    gowitness records `http://host:80` / `http://host/` (trailing slash, explicit
    default port) while httpx records `https://host` (no trailing slash, default
    port omitted) for the very same asset — exact-string matching between the two
    misses almost everything. Scheme is dropped entirely so a host screenshotted
    over http still matches an https httpx sighting (the common redirect case).
    """
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    host = parts.hostname
    if not host:
        return None
    port = parts.port
    is_default = port is None or (parts.scheme == 'http' and port == 80) or (parts.scheme == 'https' and port == 443)
    return host if is_default else f'{host}:{port}'


def _gowitness_screenshot_by_url(ws: Path) -> dict[str, str]:
    """Map {host[:port] -> "screenshots/<file>.png"} from gowitness's sqlite3 db, if present."""
    db_path = ws / "gowitness.sqlite3"
    if not db_path.exists():
        return {}
    try:
        con = sqlite3.connect(str(db_path))
        rows = con.execute(
            "SELECT filename, url, final_url FROM results WHERE filename != '' AND failed = 0"
        ).fetchall()
        con.close()
    except Exception:
        return {}
    out: dict[str, str] = {}
    for filename, url, final_url in rows:
        rel = f"screenshots/{Path(filename).name}"
        for u in (url, final_url):
            key = _netloc_key(u) if u else None
            if key and key not in out:
                out[key] = rel
    return out


# ── Scanner registry (plugin system) ──────────────────────────────────────────
# A scanner is any callable(run_id: str, ws: Path, out: list[Finding]) -> None.
# External tools can add parsers without editing this module:
#
#     from k1nzr3c0n.parsers import register_scanner
#     @register_scanner
#     def _scan_mytool(run_id, ws, out): ...

from typing import Callable  # noqa: E402

SCANNERS: list[Callable] = []


def register_scanner(fn: Callable) -> Callable:
    SCANNERS.append(fn)
    return fn


def parse_workspace(run_id: str, workspace: str) -> list[Finding]:
    """Scan a run workspace for known output files and return Finding objects."""
    ws = Path(workspace)
    if not ws.exists():
        return []

    findings: list[Finding] = []
    for scanner in SCANNERS:
        try:
            scanner(run_id, ws, findings)
        except Exception:
            # One broken output file must not zero out the whole parse.
            pass
    return findings


# Built-in scanners — registered after their definitions below (bottom of file).


# ── Nuclei JSONL ──────────────────────────────────────────────────────────────

def _scan_nuclei(run_id: str, ws: Path, out: list[Finding]) -> None:
    _VALID_SEV = {"critical", "high", "medium", "low", "info", "unknown"}
    for path in _find_files(ws, ["nuclei.jsonl", "nuclei_results.jsonl", "nuclei_urls.jsonl", "nuclei*.jsonl"]):
        for row in _iter_jsonl(path):
            sev = (row.get("info", {}).get("severity") or "info").lower()
            if sev not in _VALID_SEV:
                sev = "info"
            host = row.get("host") or row.get("ip") or ""
            out.append(Finding(
                run_id=run_id,
                kind="vuln",
                severity=sev,
                host=host,
                ip=row.get("ip"),
                name=row.get("info", {}).get("name") or row.get("template-id"),
                template_id=row.get("template-id"),
                url=row.get("matched-at") or row.get("host"),
                description=row.get("info", {}).get("description"),
                evidence=row.get("curl-command"),
                tech=json.dumps([]),
                status="open",
            ))


# ── httpx JSONL / plain-text fallback ────────────────────────────────────────

def _scan_httpx(run_id: str, ws: Path, out: list[Finding]) -> None:
    # Prefer JSONL: contains tech/title/IP
    jsonl_files = _find_files(ws, ["httpx.jsonl", "httpx.json", "http_alive.jsonl"])
    shots = _gowitness_screenshot_by_url(ws)
    for path in jsonl_files:
        for row in _iter_jsonl(path):
            url = row.get("url") or row.get("input") or ""
            host = row.get("host") or _host_from_url(url)
            tech = row.get("technologies") or row.get("tech") or []
            if isinstance(tech, str):
                tech = [tech]
            out.append(Finding(
                run_id=run_id,
                kind="http",
                severity="info",
                host=host,
                ip=_first(row.get("a")) or row.get("ip"),
                port=_int_or_none(row.get("port")),
                status_code=_int_or_none(row.get("status_code") or row.get("status-code")),
                url=url,
                title=row.get("title"),
                tech=json.dumps(tech),
                status="open",
                screenshot=shots.get(_netloc_key(url)) if url else None,
            ))
        return  # stop after first JSONL file

    # Fallback: plain-text URL list (one URL per line, from httpx without -json)
    for path in _find_files(ws, ["alive.txt", "http_alive.txt", "httpx.txt"]):
        for line in _iter_lines(path):
            if not line.startswith("http"):
                continue
            host = _host_from_url(line)
            out.append(Finding(
                run_id=run_id,
                kind="http",
                severity="info",
                host=host,
                url=line,
                tech=json.dumps([]),
                status="open",
            ))
        return


# ── naabu JSONL / plain-text fallback ────────────────────────────────────────

_NAABU_PLAIN_RE = re.compile(r'^(.+):(\d+)$')  # host:port

def _scan_naabu(run_id: str, ws: Path, out: list[Finding]) -> None:
    jsonl_files = _find_files(ws, ["naabu.jsonl", "naabu.json", "ports.jsonl"])
    for path in jsonl_files:
        for row in _iter_jsonl(path):
            host = row.get("host") or row.get("ip") or ""
            out.append(Finding(
                run_id=run_id,
                kind="port",
                severity="info",
                host=host,
                ip=row.get("ip"),
                port=_int_or_none(row.get("port")),
                protocol=row.get("protocol", "tcp"),
                name=f"Open port {row.get('port')}",
                tech=json.dumps([]),
                status="open",
            ))
        return  # stop after first JSONL file

    # Fallback: naabu plain text (host:port or ip:port one per line)
    for path in _find_files(ws, ["naabu.txt", "ports.txt"]):
        for line in _iter_lines(path):
            m = _NAABU_PLAIN_RE.match(line)
            if not m:
                continue
            host, port = m.group(1), m.group(2)
            out.append(Finding(
                run_id=run_id,
                kind="port",
                severity="info",
                host=host,
                port=_int_or_none(port),
                protocol="tcp",
                name=f"Open port {port}",
                tech=json.dumps([]),
                status="open",
            ))
        return


# ── Subdomains TXT ────────────────────────────────────────────────────────────

def _scan_subdomains(run_id: str, ws: Path, out: list[Finding]) -> None:
    for path in _find_files(ws, ["subdomains_resolved.txt", "subdomains.txt"]):
        seen: set[str] = set()
        for sub in _iter_lines(path):
            if sub and sub not in seen:
                seen.add(sub)
                out.append(Finding(
                    run_id=run_id,
                    kind="subdomain",
                    severity="info",
                    host=sub,
                    name=sub,
                    tech=json.dumps([]),
                    status="open",
                ))
        break  # prefer _resolved; don't double-count


# ── Katana JSONL (JS/endpoint crawl) ─────────────────────────────────────────

def _scan_katana(run_id: str, ws: Path, out: list[Finding]) -> None:
    seen_urls: set[str] = set()
    for path in _find_files(ws, ["katana.jsonl"]):
        for row in _iter_jsonl(path):
            # katana jsonl may have endpoint at row.request.endpoint or row.endpoint
            req = row.get("request") or {}
            url = req.get("endpoint") or row.get("endpoint") or row.get("url") or ""
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            host = _host_from_url(url)
            tech = []
            resp = row.get("response") or {}
            if resp.get("technologies"):
                tech = resp["technologies"] if isinstance(resp["technologies"], list) else [resp["technologies"]]
            out.append(Finding(
                run_id=run_id,
                kind="url",
                severity="info",
                host=host,
                url=url,
                title=req.get("tag") or req.get("attribute"),
                tech=json.dumps(tech),
                status="open",
            ))


# ── GAU JSONL (passive URL discovery) ────────────────────────────────────────

def _scan_gau(run_id: str, ws: Path, out: list[Finding]) -> None:
    seen_urls: set[str] = set()
    for path in _find_files(ws, ["gau.jsonl"]):
        for row in _iter_jsonl(path):
            url = row.get("url") or ""
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            host = _host_from_url(url)
            out.append(Finding(
                run_id=run_id,
                kind="url",
                severity="info",
                host=host,
                url=url,
                name=row.get("technique"),
                tech=json.dumps([]),
                status="open",
            ))


# ── Helpers ───────────────────────────────────────────────────────────────────

def _find_files(ws: Path, patterns: list[str]) -> list[Path]:
    # Dedupe: a wildcard pattern (e.g. "nuclei*.jsonl") can re-match files
    # already returned by an earlier explicit pattern, which would scan the same
    # file twice and duplicate every finding row.
    results: list[Path] = []
    seen: set[Path] = set()
    for pat in patterns:
        for p in ws.glob(pat):
            if p not in seen:
                seen.add(p)
                results.append(p)
    return results


def _iter_jsonl(path: Path):
    try:
        for line in path.read_text(errors="replace").splitlines():
            line = line.strip()
            if line:
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    pass
    except OSError:
        pass


def _iter_lines(path: Path) -> list[str]:
    try:
        return [l.strip() for l in path.read_text(errors="replace").splitlines() if l.strip()]
    except OSError:
        return []


def _host_from_url(url: str) -> str:
    if "://" in url:
        return url.split("://", 1)[1].split("/")[0].split(":")[0]
    return url


def _int_or_none(val) -> int | None:
    try:
        return int(val)
    except (TypeError, ValueError):
        return None


def _first(lst) -> str | None:
    if isinstance(lst, list) and lst:
        return str(lst[0])
    return None


# ── Built-in scanner registration ─────────────────────────────────────────────
for _fn in (_scan_nuclei, _scan_httpx, _scan_naabu,
            _scan_subdomains, _scan_katana, _scan_gau):
    register_scanner(_fn)
